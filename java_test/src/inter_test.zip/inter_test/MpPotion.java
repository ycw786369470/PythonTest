package inter_test;

public class MpPotion extends Item {
    public void effect(String name){
        System.out.println(name + "吃了回蓝水");
    }
}
