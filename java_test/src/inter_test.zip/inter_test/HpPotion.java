package inter_test;

public class HpPotion extends Item {
    public void effect(String name){
        System.out.println(name + "吃了补血散");
    }
}
