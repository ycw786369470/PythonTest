package inter_test;

public interface AdAttack {
    public void AdDamage(Hero be_atack);
}
